/**
 * Created by Administrator on 2017/2/7.
 */
(function(angular){
    var module = angular.module('moviecat.top_250',['ngRoute']);
    //配置路由
    module.config(['$routeProvider',function($routeProvider){
        $routeProvider
            .when('/top_250',{
                controller: 'Top250Controller',
                templateUrl:'top_250/view.html'
            })
    }]);

    //配置控制器
    module.controller('Top250Controller',['$scope',function($scope){

    }]);
})(angular);